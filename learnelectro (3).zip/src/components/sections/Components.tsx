import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Cpu, Zap, Target, Activity, X, ExternalLink, Info, CheckCircle2, AlertCircle, FlaskConical, MousePointer2, ArrowRight } from 'lucide-react';
import { electronicComponents } from '../../data/components';
import { ElectronicComponent, CircuitExample, CircuitPart } from '../../types';
import { cn } from '../../lib/utils';

interface ComponentsProps {
  searchQuery?: string;
}

export default function Components({ searchQuery = '' }: ComponentsProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedComponent, setSelectedComponent] = useState<ElectronicComponent | null>(null);
  const [hoveredPart, sethoveredPart] = useState<CircuitPart | null>(null);
  const [showSimulation, setShowSimulation] = useState<string | null>(null);

  // Sync internal search with global search
  const effectiveSearch = searchTerm || searchQuery;

  const categories = [
    { id: 'Passive', label: 'Passive', icon: Zap, color: 'text-sky-400', bg: 'bg-sky-500/10' },
    { id: 'Semiconductor', label: 'Active', icon: Activity, color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
    { id: 'IC', label: 'IC Units', icon: Cpu, color: 'text-sky-400', bg: 'bg-sky-500/10' },
    { id: 'Sensor', label: 'Sensors', icon: Target, color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
  ];

  const featuredIds = ['resistor-passive', 'mosfet-semiconductor', 'esp32-mcu'];
  const featuredComponents = electronicComponents.filter(c => featuredIds.includes(c.id));

  const filteredComponents = electronicComponents.filter(comp => {
    const matchesSearch = comp.name.toLowerCase().includes(effectiveSearch.toLowerCase()) || 
                          comp.description.toLowerCase().includes(effectiveSearch.toLowerCase());
    const matchesCategory = !selectedCategory || comp.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <section className="container mx-auto px-6 md:px-8 py-10 md:py-24 relative">
      {/* Background Glows */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-sky-500/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-indigo-500/5 blur-[120px] rounded-full pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-8 mb-10 md:mb-16">
        <div className="text-center md:text-left">
          <motion.h2 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-3xl md:text-5xl font-black tracking-tighter text-white"
          >
            Technical <span className="text-sky-400">Library</span>
          </motion.h2>
          <p className="text-slate-400 text-sm md:text-base font-medium mt-2">Deep architectural data for engineering students</p>
        </div>
        
        <div className="relative w-full max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search components (e.g. Resistor, BJT)..."
            className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-6 focus:outline-none focus:border-sky-500 transition-all text-white font-medium focus:ring-2 focus:ring-sky-500/20"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Featured Section */}
      {!selectedCategory && !effectiveSearch && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16"
        >
          <div className="flex items-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-lg bg-sky-500/20 flex items-center justify-center text-sky-400 font-black text-xs">01</div>
            <h3 className="text-xl font-bold text-white">Popular Components</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredComponents.map((comp) => (
              <div 
                key={comp.id}
                onClick={() => setSelectedComponent(comp)}
                className="group relative h-48 rounded-[32px] overflow-hidden border border-white/5 hover:border-sky-500/50 transition-all cursor-pointer"
              >
                <img src={comp.image} className="w-full h-full object-cover opacity-40 group-hover:opacity-60 transition-all duration-700" alt="" />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent p-6 flex flex-col justify-end">
                   <div className="text-[10px] font-black text-sky-400 uppercase tracking-widest mb-1">{comp.category}</div>
                   <h4 className="text-xl font-black text-white">{comp.name}</h4>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Categories */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
        {categories.map((cat) => (
          <motion.div
            key={cat.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setSelectedCategory(selectedCategory === cat.id ? null : cat.id)}
            className={cn(
              "flex items-center gap-4 px-6 py-5 rounded-3xl border transition-all cursor-pointer group backdrop-blur-md",
              selectedCategory === cat.id 
                ? "bg-sky-500/20 border-sky-500 shadow-[0_0_30px_rgba(14,165,233,0.3)]" 
                : "bg-white/5 border-white/5 hover:border-white/10 hover:bg-white/[0.08]"
            )}
          >
            <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:rotate-12", cat.bg)}>
              <cat.icon className={cn("w-6 h-6", cat.color)} />
            </div>
            <div>
              <div className="text-[11px] text-slate-400 font-black uppercase tracking-widest">{cat.label}</div>
              <div className="text-lg font-bold text-white">Explore</div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        <AnimatePresence mode="popLayout">
          {filteredComponents.map((comp) => (
            <motion.div
              key={comp.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              whileHover={{ 
                y: -8, 
                boxShadow: "0 20px 40px rgba(0,0,0,0.4)",
              }}
              onClick={() => setSelectedComponent(comp)}
              className="group relative bg-white/[0.03] backdrop-blur-xl border border-white/5 rounded-[32px] overflow-hidden hover:border-sky-500/30 transition-all p-6 cursor-pointer hover:shadow-[0_0_30px_rgba(14,165,233,0.1)]"
            >
              <div className="aspect-video rounded-2xl bg-slate-800/50 mb-6 flex items-center justify-center overflow-hidden relative">
                 <img 
                  src={comp.image} 
                  alt={comp.name}
                  className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-all duration-700"
                 />
                 <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent" />
                 <div className="absolute top-4 right-4 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-[10px] font-black uppercase tracking-widest text-white border border-white/10">
                   {comp.category}
                 </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black uppercase tracking-widest text-sky-400">Component Module</span>
                  <div className="flex items-center gap-1">
                    <span className="w-1 h-1 rounded-full bg-emerald-500" />
                    <span className="text-[10px] font-mono text-slate-400">READY</span>
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-white group-hover:text-sky-400 transition-colors tracking-tight">{comp.name}</h3>
                <p className="text-slate-400 text-sm leading-relaxed line-clamp-2 font-medium">{comp.description}</p>
              </div>
              <div className="mt-6 pt-6 border-t border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-4">
                   <div className="flex -space-x-2">
                      {[1,2,3].map(i => <div key={i} className="w-6 h-6 rounded-full border border-slate-950 bg-sky-500/20" />)}
                   </div>
                   <span className="text-[10px] font-bold text-slate-500 uppercase">Used by Batch</span>
                </div>
                <button className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-sky-400 group-hover:translate-x-1 transition-transform">
                  Analyze
                  <ArrowRight size={14} />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Component Details Modal */}
      <AnimatePresence>
        {selectedComponent && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setSelectedComponent(null);
                sethoveredPart(null);
                setShowSimulation(null);
              }}
              className="absolute inset-0 bg-slate-950/90 backdrop-blur-md"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-5xl max-h-[90vh] bg-slate-900 border border-white/10 rounded-[40px] shadow-2xl flex flex-col overflow-hidden"
            >
              {/* Modal Header */}
              <div className="p-8 border-b border-white/5 flex items-center justify-between sticky top-0 bg-slate-900 z-10">
                <div className="flex items-center gap-6">
                  <div className="w-16 h-16 rounded-2xl bg-sky-500/10 flex items-center justify-center">
                    <Cpu className="w-8 h-8 text-sky-400" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 bg-sky-500/10 text-sky-400 text-[10px] font-black uppercase rounded">{selectedComponent.category}</span>
                      <span className="text-slate-500 text-[10px] font-mono">ID: {selectedComponent.id}</span>
                    </div>
                    <h2 className="text-3xl font-black text-white">{selectedComponent.name}</h2>
                  </div>
                </div>
                <button 
                  onClick={() => {
                    setSelectedComponent(null);
                    sethoveredPart(null);
                    setShowSimulation(null);
                  }}
                  className="w-12 h-12 rounded-xl bg-white/5 hover:bg-white/10 transition-colors flex items-center justify-center text-white"
                >
                  <X />
                </button>
              </div>

              {/* Modal Content */}
              <div className="flex-1 overflow-y-auto p-8 no-scrollbar">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                  {/* Left Column: Visuals */}
                  <div className="lg:col-span-5 space-y-8">
                    <div className="aspect-square rounded-[32px] bg-slate-800/50 border border-white/5 overflow-hidden p-8 flex items-center justify-center group">
                      <img 
                        src={selectedComponent.image} 
                        alt={selectedComponent.name}
                        className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    
                    <div className="p-6 rounded-3xl bg-sky-500/5 border border-sky-500/20">
                      <h4 className="text-xs font-black uppercase tracking-widest text-sky-400 mb-4 flex items-center gap-2">
                        <Info size={14} />
                        Engineering Formula
                      </h4>
                      <div className="text-3xl font-mono font-bold text-white text-center py-4 bg-black/20 rounded-2xl border border-white/5">
                        {selectedComponent.formula || 'Varies by application'}
                      </div>
                    </div>

                    <div className="p-6 rounded-3xl bg-white/5 border border-white/5">
                      <h4 className="text-xs font-black uppercase tracking-widest text-slate-500 mb-4">Typical Applications</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedComponent.applications.map((app, i) => (
                          <span key={i} className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs font-medium text-slate-300">
                            {app}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Information */}
                  <div className="lg:col-span-7 space-y-12">
                    <section>
                      <h3 className="text-xl font-bold text-white mb-4">Functional Working</h3>
                      <p className="text-slate-400 leading-relaxed text-lg">
                        {selectedComponent.working}
                      </p>
                    </section>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <section className="space-y-4">
                        <h4 className="text-sm font-black uppercase tracking-widest text-emerald-400 flex items-center gap-2">
                          <CheckCircle2 size={16} />
                          Advantages
                        </h4>
                        <ul className="space-y-3">
                          {selectedComponent.advantages.map((adv, i) => (
                            <li key={i} className="flex gap-3 text-sm text-slate-400">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                              {adv}
                            </li>
                          ))}
                        </ul>
                      </section>
                      <section className="space-y-4">
                        <h4 className="text-sm font-black uppercase tracking-widest text-rose-400 flex items-center gap-2">
                          <AlertCircle size={16} />
                          Disadvantages
                        </h4>
                        <ul className="space-y-3">
                          {selectedComponent.disadvantages.map((dis, i) => (
                            <li key={i} className="flex gap-3 text-sm text-slate-400">
                              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                              {dis}
                            </li>
                          ))}
                        </ul>
                      </section>
                    </div>

                    <section className="p-8 rounded-[32px] bg-sky-500/10 border border-sky-500/10 space-y-4">
                      <h3 className="text-xl font-bold text-white flex items-center gap-2">
                        <Target className="text-sky-400" size={20} />
                        Revision Quick Summary
                      </h3>
                      <ul className="space-y-3">
                        {selectedComponent.revisionNotes?.map((note, i) => (
                          <li key={i} className="flex gap-3 text-sm text-slate-300">
                             <div className="w-5 h-5 rounded bg-sky-500/20 flex items-center justify-center shrink-0 text-[10px] font-black text-sky-400">
                               {i + 1}
                             </div>
                             {note}
                          </li>
                        )) || (
                          <li className="text-slate-500 text-sm italic">Revision notes pending for this architectural module.</li>
                        )}
                      </ul>
                    </section>

                    <section className="space-y-6 overflow-hidden">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <h3 className="text-lg md:text-xl font-bold text-white flex items-center gap-2">
                          <FlaskConical className="text-sky-400" size={22} />
                          Real Circuit Examples
                        </h3>
                        <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 bg-white/5 px-2 py-1 rounded">Interactive Prototype</span>
                      </div>

                      <div className="space-y-8">
                        {selectedComponent.circuitExamples?.map((example) => (
                          <div key={example.id} className="bg-slate-950/50 border border-white/5 rounded-2xl md:rounded-[32px] p-4 md:p-8 space-y-4 md:space-y-6">
                            <div className="space-y-1 md:space-y-2">
                              <h4 className="text-base md:text-lg font-bold text-sky-400">{example.title}</h4>
                              <p className="text-slate-400 text-xs md:text-sm leading-relaxed">{example.description}</p>
                            </div>

                            <div className="relative aspect-[4/3] md:aspect-video rounded-xl md:rounded-2xl bg-black/60 border border-white/10 overflow-hidden group/circuit">
                              <img 
                                src={example.diagram} 
                                alt={example.title}
                                className="w-full h-full object-cover opacity-70 md:opacity-50 grayscale md:grayscale hover:grayscale-0 transition-all duration-700"
                                referrerPolicy="no-referrer"
                              />
                              
                              {/* Interaction Hint */}
                              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent opacity-100 flex items-end p-4 pointer-events-none">
                                <div className="flex items-center gap-2 text-[9px] md:text-[10px] font-bold text-white uppercase tracking-widest bg-slate-950/60 backdrop-blur-md border border-white/10 px-3 py-1.5 rounded-full shadow-xl">
                                  <MousePointer2 size={12} className="text-sky-400" />
                                  <span className="hidden sm:inline">Hover/Tap hotspots to analyze parts</span>
                                  <span className="sm:hidden">Tap hotspots to explore</span>
                                </div>
                              </div>

                              {/* Hotspots */}
                              {example.parts.map((part) => (
                                <div 
                                  key={part.id}
                                  className="absolute w-12 h-12 -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10 flex items-center justify-center p-2"
                                  style={{ left: `${part.position.x}%`, top: `${part.position.y}%` }}
                                  onMouseEnter={() => sethoveredPart(part)}
                                  onMouseLeave={() => sethoveredPart(null)}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    sethoveredPart(hoveredPart?.id === part.id ? null : part);
                                  }}
                                >
                                  <div className="absolute inset-2 bg-sky-500/30 rounded-full animate-ping" />
                                  <div className="relative w-4 h-4 md:w-3 md:h-3 bg-sky-500 rounded-full border-2 border-white shadow-[0_0_15px_rgba(14,165,233,0.8)]" />

                                  <AnimatePresence>
                                    {hoveredPart?.id === part.id && (
                                      <motion.div
                                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                        animate={{ opacity: 1, y: 0, scale: 1 }}
                                        exit={{ opacity: 0, scale: 0.95 }}
                                        className={cn(
                                          "absolute w-36 md:w-48 p-3 bg-slate-900/95 backdrop-blur-md border border-sky-500/50 rounded-xl shadow-2xl z-[150] pointer-events-none",
                                          part.position.y > 50 ? "bottom-full mb-4" : "top-full mt-4"
                                        )}
                                        style={{ left: '50%', transform: 'translateX(-50%)' }}
                                      >
                                        <div className="text-[10px] md:text-xs font-black text-sky-400 uppercase tracking-widest mb-1">{part.name}</div>
                                        <div className="text-[10px] md:text-[11px] text-slate-200 leading-snug font-medium">{part.explanation}</div>
                                        <div className={cn(
                                          "absolute left-1/2 -translate-x-1/2 border-8 border-transparent",
                                          part.position.y > 50 ? "top-full border-t-slate-900" : "bottom-full border-b-slate-900"
                                        )} />
                                      </motion.div>
                                    )}
                                  </AnimatePresence>
                                </div>
                              ))}
                            </div>

                            <div className="flex flex-col gap-4">
                              <button 
                                onClick={() => setShowSimulation(showSimulation === example.id ? null : example.id)}
                                className={cn(
                                  "w-full px-6 py-4 rounded-xl font-bold text-xs md:text-sm transition-all flex items-center justify-center gap-2",
                                  showSimulation === example.id 
                                    ? "bg-sky-500 text-slate-950 shadow-[0_0_20px_rgba(14,165,233,0.3)]" 
                                    : "bg-white/5 text-white hover:bg-white/10 border border-white/10"
                                )}
                              >
                                <Zap size={16} />
                                {showSimulation === example.id ? 'Hide Active Simulation' : 'Run Basic Simulation'}
                              </button>
                              
                              <AnimatePresence>
                                {showSimulation === example.id && (
                                  <motion.div 
                                    initial={{ opacity: 0, height: 0 }}
                                    animate={{ opacity: 1, height: 'auto' }}
                                    exit={{ opacity: 0, height: 0 }}
                                    className="overflow-hidden"
                                  >
                                    <div className="p-3 md:p-5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl md:rounded-2xl flex items-start gap-3 md:gap-4">
                                      <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
                                        <Activity className="text-emerald-400" size={16} />
                                      </div>
                                      <div>
                                        <div className="text-[9px] md:text-[10px] font-black uppercase tracking-widest text-emerald-400 mb-0.5 md:mb-1">Live Simulation Output</div>
                                        <div className="text-slate-300 text-xs md:text-base leading-relaxed font-medium italic">"{example.simulationResult}"</div>
                                      </div>
                                    </div>
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </div>
                          </div>
                        )) || (
                          <div className="p-12 rounded-[32px] border border-dashed border-white/10 flex flex-col items-center justify-center text-center space-y-4">
                            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center">
                              <FlaskConical className="text-slate-600" />
                            </div>
                            <div>
                              <p className="text-slate-400 font-bold">No interactive examples yet</p>
                              <p className="text-slate-500 text-sm">Advanced circuit models are being rendered for this component.</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </section>

                    <section className="p-8 rounded-[32px] bg-slate-950/50 border border-white/5 space-y-6">
                      <h3 className="text-xl font-bold text-white flex items-center gap-2">
                        <Zap className="text-sky-400" size={20} />
                        Viva / Interview Q&A
                      </h3>
                      <div className="space-y-6">
                        {selectedComponent.interviewQuestions.map((qa, i) => (
                          <div key={i} className="space-y-2 group">
                            <p className="text-sm font-bold text-sky-400">Q: {qa.q}</p>
                            <p className="text-sm text-slate-400 leading-relaxed pl-4 border-l border-white/10 group-hover:border-sky-500/50 transition-colors">
                              {qa.a}
                            </p>
                          </div>
                        ))}
                      </div>
                    </section>

                    <div className="flex gap-4">
                      <button className="flex-1 py-4 bg-sky-500 text-slate-950 font-bold rounded-2xl shadow-lg shadow-sky-500/20 hover:scale-[1.02] transition-all">
                        Take Quiz on {selectedComponent.name}
                      </button>
                      <button className="flex-1 py-4 bg-white/5 border border-white/10 text-white font-bold rounded-2xl hover:bg-white/10 transition-all">
                         Download Data Sheet
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
