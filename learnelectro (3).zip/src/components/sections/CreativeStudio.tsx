import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Download, RefreshCw, Send, Image as ImageIcon, Cpu, Zap, Wand2 } from 'lucide-react';
import { generateEngineeringImage } from '../../services/gemini';
import { cn } from '../../lib/utils';

export default function CreativeStudio() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setGeneratedImage(null);
    setError(null);
    
    try {
      const imageUrl = await generateEngineeringImage(prompt);
      if (imageUrl) {
        setGeneratedImage(imageUrl);
      } else {
        setError("Failed to generate image. Please try a different prompt.");
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An error occurred during generation.");
    } finally {
      setIsGenerating(false);
    }
  };

  const suggestions = [
    "Cross-section of a high-power MOSFET",
    "Futuristic microcontroller with glowing traces",
    "Schematic of an advanced RF amplifier",
    "3D render of a gallium nitride transistor",
  ];

  return (
    <section className="container mx-auto px-6 md:px-8 py-10 md:py-24">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10 md:mb-16">
          <h2 className="text-3xl md:text-5xl font-black tracking-tighter text-white">
            AI Design <span className="text-sky-400">Lab</span>
          </h2>
          <p className="text-slate-500 text-sm md:text-base font-medium mt-2">
            Generate high-fidelity technical illustrations for your engineering projects
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Controls */}
          <div className="space-y-8">
            <div className="bg-white/5 border border-white/10 rounded-[32px] p-8 space-y-6">
              <div className="space-y-4">
                <label className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                  <Wand2 size={14} className="text-sky-400" />
                  What are you designing?
                </label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="e.g., A high-precision operational amplifier circuit with gold-plated pads..."
                  className="w-full h-32 bg-black/20 border border-white/10 rounded-2xl p-6 text-white placeholder:text-slate-600 focus:outline-none focus:border-sky-500 transition-colors resize-none font-medium"
                />
              </div>

              <div className="flex flex-wrap gap-2">
                {suggestions.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => setPrompt(s)}
                    className="px-3 py-1.5 bg-white/5 border border-white/5 rounded-xl text-[10px] font-bold text-slate-400 hover:text-sky-400 hover:border-sky-500/20 transition-all uppercase tracking-tight"
                  >
                    {s}
                  </button>
                ))}
              </div>

              <button
                onClick={handleGenerate}
                disabled={isGenerating || !prompt.trim()}
                className="w-full py-5 bg-sky-500 text-slate-950 font-black rounded-2xl shadow-[0_0_30px_rgba(14,165,233,0.3)] hover:scale-[1.02] active:scale-98 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="animate-spin" />
                    Synthesizing Visuals...
                  </>
                ) : (
                  <>
                    <Sparkles />
                    Generate Illustration
                  </>
                )}
              </button>
            </div>

            <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-[32px] p-8">
              <h4 className="text-xs font-black uppercase tracking-widest text-indigo-400 mb-4 flex items-center gap-2">
                <Cpu size={14} />
                Model Details
              </h4>
              <p className="text-sm text-slate-400 leading-relaxed">
                Powered by <span className="text-white font-bold">Gemini 2.5 Flash Image</span>. 
                Optimized for technical accuracy and engineering aesthetic. 
                Higher detail is achieved with specific component names and materials.
              </p>
            </div>
          </div>

          {/* Preview */}
          <div className="bg-slate-900/40 border border-white/10 rounded-[40px] aspect-square relative flex items-center justify-center overflow-hidden group">
             <div className="absolute inset-0 opacity-10" 
              style={{ 
                backgroundImage: `linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)`,
                backgroundSize: '40px 40px'
              }} 
            />

            <AnimatePresence mode="wait">
              {isGenerating ? (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center gap-4 text-sky-400"
                >
                  <div className="w-16 h-16 border-4 border-sky-400/20 border-t-sky-400 rounded-full animate-spin" />
                  <span className="text-[10px] font-black uppercase tracking-widest animate-pulse">Rendering Neural Network</span>
                </motion.div>
              ) : generatedImage ? (
                <motion.div
                  key="image"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="w-full h-full p-4 relative group"
                >
                  <img
                    src={generatedImage}
                    alt="Generated engineering visual"
                    className="w-full h-full object-cover rounded-[32px] shadow-2xl border border-white/10"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-x-8 bottom-8 flex gap-4 opacity-0 group-hover:opacity-100 transition-opacity translate-y-4 group-hover:translate-y-0 duration-300">
                    <button 
                      onClick={() => {
                        const link = document.createElement('a');
                        link.href = generatedImage;
                        link.download = 'learnelectro-custom-design.png';
                        link.click();
                      }}
                      className="flex-1 py-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl text-white font-bold text-xs flex items-center justify-center gap-2 hover:bg-white/20"
                    >
                      <Download size={16} />
                      Download HD
                    </button>
                  </div>
                </motion.div>
              ) : error ? (
                <motion.div
                  key="error"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center gap-4 text-rose-500 p-8 text-center"
                >
                  <Zap size={48} className="animate-pulse" />
                  <div>
                    <div className="text-sm font-bold uppercase">Synthesizer Fault</div>
                    <p className="text-xs text-slate-500 mt-1">{error}</p>
                  </div>
                </motion.div>
              ) : (
                <div className="flex flex-col items-center gap-4 text-slate-600">
                  <ImageIcon size={64} strokeWidth={1} />
                  <span className="text-[10px] font-black uppercase tracking-widest">Input Parameters & Ignite</span>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
