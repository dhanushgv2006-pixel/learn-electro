import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Activity, Play, RotateCcw, Save, Settings, ShieldCheck, Zap } from 'lucide-react';

export default function VirtualLab() {
  const [voltage, setVoltage] = useState(5);
  const [isRunning, setIsRunning] = useState(false);

  return (
    <section className="container mx-auto px-6 md:px-8 py-10 md:py-24">
      <div className="mb-10 md:mb-16">
        <h2 className="text-3xl md:text-5xl font-black tracking-tighter text-white">
          Virtual <span className="text-sky-400">Simulation Lab</span>
        </h2>
        <p className="text-slate-400 text-sm md:text-base font-medium mt-2">Test your circuits in a real-time high-fidelity environment</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Workspace */}
        <div className="lg:col-span-2 bg-slate-900/40 border border-white/10 rounded-[40px] p-4 md:p-8 aspect-square md:aspect-video relative flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 opacity-10" 
            style={{ 
              backgroundImage: `linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)`,
              backgroundSize: '40px 40px'
            }} 
          />
          
          <div className="relative z-10 flex flex-col items-center gap-8">
            <div className="flex items-center gap-16">
              {/* Battery */}
               <div className="flex flex-col items-center gap-4">
                <div className="w-16 h-24 bg-slate-800 border-2 border-white/20 rounded-lg relative flex flex-col justify-end p-2">
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-8 h-2 bg-white/20 rounded-t-sm" />
                  <div className="w-full bg-emerald-500 rounded" style={{ height: `${(voltage / 12) * 100}%` }} />
                </div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Power Source</span>
              </div>

              {/* Wire Bridge */}
              <div className="w-32 h-[2px] bg-slate-700 relative">
                {isRunning && (
                   <motion.div 
                    animate={{ x: [0, 128] }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="absolute -top-1 w-2 h-2 bg-sky-400 rounded-full shadow-[0_0_10px_#0ea5e9]"
                   />
                )}
              </div>

              {/* Component Slot (LED) */}
              <div className="flex flex-col items-center gap-4">
                <div className={`w-16 h-16 rounded-full border-4 ${isRunning ? 'border-sky-400 bg-sky-500/20 shadow-[0_0_30px_#0ea5e9]' : 'border-white/10 bg-white/5'} transition-all duration-300 flex items-center justify-center`}>
                   <Zap className={`w-8 h-8 ${isRunning ? 'text-sky-400 fill-sky-400' : 'text-white/10'}`} />
                </div>
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Load (LED)</span>
              </div>
            </div>
          </div>

          <div className="absolute bottom-8 left-8 right-8 flex justify-between items-center bg-black/40 backdrop-blur-md border border-white/5 p-4 rounded-2xl">
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setIsRunning(!isRunning)}
                className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${isRunning ? 'bg-red-500/20 text-red-400 border-red-500/30' : 'bg-sky-500 text-slate-950 border-sky-400 shadow-[0_0_20px_#0ea5e966]' } border font-bold`}
              >
                {isRunning ? <RotateCcw size={20} /> : <Play size={20} />}
              </button>
              <div>
                <div className="text-[10px] text-slate-400 font-black tracking-widest uppercase">Status</div>
                <div className="text-sm font-bold text-white uppercase">{isRunning ? 'Simulation Active' : 'System Idle'}</div>
              </div>
            </div>

            <div className="flex items-center gap-4">
               <div className="text-right">
                <div className="text-[10px] text-slate-400 font-black tracking-widest uppercase">Consumption</div>
                <div className="text-sm font-bold text-emerald-400">{isRunning ? (voltage * 0.25).toFixed(2) : '0.00'} mA</div>
              </div>
              <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="space-y-6">
          <div className="bg-white/5 border border-white/10 rounded-[32px] p-8 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Settings className="w-5 h-5 text-sky-400" />
                Parameters
              </h3>
              <Badge content="Pro" />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-end">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Input Voltage (V)</label>
                <div className="text-2xl font-black text-white">{voltage}V</div>
              </div>
              <input 
                type="range" 
                min="0" 
                max="12" 
                step="0.1"
                value={voltage}
                onChange={(e) => setVoltage(parseFloat(e.target.value))}
                className="w-full accent-sky-500 h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-bold text-slate-600">
                <span>0V</span>
                <span>6V (Std)</span>
                <span>12V (Max)</span>
              </div>
            </div>

            <div className="pt-6 border-t border-white/5 grid grid-cols-2 gap-4">
              <button className="py-3 rounded-xl bg-white/5 border border-white/10 text-xs font-bold uppercase tracking-widest hover:bg-white/10 transition-colors">
                Apply Load
              </button>
              <button className="py-3 rounded-xl bg-white/5 border border-white/10 text-xs font-bold uppercase tracking-widest hover:bg-white/10 transition-colors">
                Toggle AC/DC
              </button>
            </div>
          </div>

          <div className="bg-sky-500/10 border border-sky-500/20 rounded-[32px] p-8">
            <h3 className="text-lg font-bold text-sky-400 mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5" />
              Efficiency Data
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Power Dissipated</span>
                <span className="text-white font-bold">{(voltage * (isRunning ? 0.02 : 0)).toFixed(2)} Watts</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Heat Coefficient</span>
                <span className="text-white font-bold">+0.42 °C/W</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Peak Current Limit</span>
                <span className="text-white font-bold">500 mA</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Badge({ content }: { content: string }) {
  return (
    <span className="px-2 py-1 rounded bg-sky-500 text-slate-950 text-[10px] font-black uppercase tracking-widest">
      {content}
    </span>
  );
}
