import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, XCircle, ChevronRight, RotateCcw, Award, BrainCircuit, Timer, HelpCircle } from 'lucide-react';
import { quizQuestions, Question } from '../../data/quiz';
import { cn } from '../../lib/utils';

export default function Assessment() {
  const [currentStep, setCurrentStep] = useState<'intro' | 'quiz' | 'result'>('intro');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);

  const currentQuestion = quizQuestions[currentIndex];

  const handleStart = () => {
    setCurrentStep('quiz');
    setCurrentIndex(0);
    setScore(0);
    setUserAnswers([]);
    setSelectedAnswer(null);
    setIsAnswered(false);
  };

  const handleSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedAnswer(index);
    setIsAnswered(true);
    
    const correct = index === currentQuestion.correctAnswer;
    if (correct) setScore(s => s + 1);
    setUserAnswers(prev => [...prev, index]);
  };

  const handleNext = () => {
    if (currentIndex < quizQuestions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
    } else {
      setCurrentStep('result');
    }
  };

  const scorePercentage = (score / quizQuestions.length) * 100;

  return (
    <div className="container mx-auto px-6 md:px-8 py-10 md:py-24">
      <div className="max-w-3xl mx-auto">
        <AnimatePresence mode="wait">
          {currentStep === 'intro' && (
            <motion.div
              key="intro"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="text-center space-y-8 bg-white/5 border border-white/10 rounded-[32px] md:rounded-[40px] p-8 md:p-12 backdrop-blur-xl"
            >
              <div className="w-20 h-20 bg-sky-500 rounded-3xl mx-auto flex items-center justify-center shadow-[0_0_40px_rgba(14,165,233,0.3)]">
                <BrainCircuit className="text-slate-950 w-10 h-10" />
              </div>
              <div>
                <h2 className="text-4xl font-black text-white">Engineering Assessment</h2>
                <p className="text-slate-400 mt-4 text-lg">Test your knowledge on basic electronics, components, and circuit theory.</p>
              </div>
              <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
                <div className="p-4 bg-black/20 rounded-2xl border border-white/5">
                  <HelpCircle className="text-sky-400 mx-auto mb-2" />
                  <div className="text-xs font-black text-slate-500 uppercase">Questions</div>
                  <div className="text-xl font-bold text-white">{quizQuestions.length}</div>
                </div>
                <div className="p-4 bg-black/20 rounded-2xl border border-white/5">
                  <Award className="text-emerald-400 mx-auto mb-2" />
                  <div className="text-xs font-black text-slate-500 uppercase">Difficulty</div>
                  <div className="text-xl font-bold text-white">Mixed</div>
                </div>
              </div>
              <button
                onClick={handleStart}
                className="px-12 py-5 bg-sky-500 text-slate-950 font-black rounded-2xl hover:scale-105 transition-all shadow-xl"
              >
                Start Assessment
              </button>
            </motion.div>
          )}

          {currentStep === 'quiz' && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <div className="px-4 py-1.5 bg-sky-500/10 border border-sky-500/20 rounded-full text-sky-400 text-[10px] font-black uppercase tracking-widest">
                  Question {currentIndex + 1} of {quizQuestions.length}
                </div>
                <div className="h-1 whe-full max-w-xs bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentIndex + 1) / quizQuestions.length) * 100}%` }}
                    className="h-full bg-sky-500"
                  />
                </div>
              </div>

              <div className="space-y-6">
                <h3 className="text-3xl font-bold text-white leading-tight">
                  {currentQuestion.question}
                </h3>
                
                <div className="grid grid-cols-1 gap-4">
                  {currentQuestion.options.map((option, i) => (
                    <button
                      key={i}
                      disabled={isAnswered}
                      onClick={() => handleSelect(i)}
                      className={cn(
                        "p-6 rounded-2xl text-left border transition-all relative overflow-hidden group",
                        !isAnswered && "bg-white/5 border-white/10 hover:border-sky-500/50 hover:bg-white/[0.08]",
                        isAnswered && i === currentQuestion.correctAnswer && "bg-emerald-500/10 border-emerald-500/50 text-emerald-400",
                        isAnswered && selectedAnswer === i && i !== currentQuestion.correctAnswer && "bg-rose-500/10 border-rose-500/50 text-rose-400",
                        isAnswered && selectedAnswer !== i && i !== currentQuestion.correctAnswer && "bg-white/5 border-white/5 opacity-50"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{option}</span>
                        {isAnswered && i === currentQuestion.correctAnswer && <CheckCircle2 size={20} />}
                        {isAnswered && selectedAnswer === i && i !== currentQuestion.correctAnswer && <XCircle size={20} />}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <AnimatePresence>
                {isAnswered && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-6 bg-sky-500/10 border border-sky-500/10 rounded-2xl flex items-start gap-4"
                  >
                    <div className="w-10 h-10 rounded-xl bg-sky-500/20 flex items-center justify-center shrink-0">
                      <BrainCircuit size={20} className="text-sky-400" />
                    </div>
                    <div>
                      <p className="text-sm text-slate-300 leading-relaxed">
                        {currentQuestion.explanation}
                      </p>
                      <button
                        onClick={handleNext}
                        className="mt-4 px-6 py-2 bg-sky-500 text-slate-950 font-bold rounded-xl flex items-center gap-2 hover:scale-105 transition-transform"
                      >
                        {currentIndex === quizQuestions.length - 1 ? 'See Results' : 'Next Question'}
                        <ChevronRight size={18} />
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}

          {currentStep === 'result' && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center space-y-12 bg-white/5 border border-white/10 rounded-[40px] p-12 backdrop-blur-xl"
            >
              <div className="relative inline-block">
                <svg className="w-48 h-48">
                  <circle
                    className="text-white/5"
                    strokeWidth="12"
                    stroke="currentColor"
                    fill="transparent"
                    r="86"
                    cx="96"
                    cy="96"
                  />
                  <motion.circle
                    className="text-sky-500"
                    strokeWidth="12"
                    strokeDasharray={2 * Math.PI * 86}
                    initial={{ strokeDashoffset: 2 * Math.PI * 86 }}
                    animate={{ strokeDashoffset: (2 * Math.PI * 86) * (1 - score / quizQuestions.length) }}
                    transition={{ duration: 1.5, ease: "easeOut" }}
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="transparent"
                    r="86"
                    cx="96"
                    cy="96"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-5xl font-black text-white">{Math.round(scorePercentage)}%</span>
                  <span className="text-xs font-black text-slate-500 uppercase mt-1">Acquired Score</span>
                </div>
              </div>

              <div className="space-y-4">
                <h2 className="text-3xl font-black text-white">
                  {scorePercentage >= 80 ? 'Distinguished Performance!' : scorePercentage >= 60 ? 'Standard Performance' : 'Continuous Effort Needed'}
                </h2>
                <p className="text-slate-400">You correctly answered {score} out of {quizQuestions.length} engineering propositions.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-md mx-auto">
                <button
                  onClick={handleStart}
                  className="flex items-center justify-center gap-2 p-5 bg-white/10 border border-white/10 rounded-2xl text-white font-bold hover:bg-white/20 transition-all"
                >
                  <RotateCcw size={20} />
                  Retake Test
                </button>
                <button
                   onClick={() => window.location.reload()} // Navigation hack or setter
                   className="flex items-center justify-center gap-2 p-5 bg-sky-500 text-slate-950 font-bold rounded-2xl hover:scale-105 transition-all"
                >
                  Return to Base
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
