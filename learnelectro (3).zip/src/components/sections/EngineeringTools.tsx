import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calculator, Zap, Activity, ShieldCheck, RefreshCw, Layers, Lightbulb, Search } from 'lucide-react';
import { cn } from '../../lib/utils';

interface ToolsProps {
  searchQuery?: string;
}

export default function EngineeringTools({ searchQuery = '' }: ToolsProps) {
  const [activeTab, setActiveTab] = useState<'ohms' | 'resistor' | 'led' | 'rc'>('ohms');
  
  // Ohm's Law State
  const [v, setV] = useState<string>('');
  const [i, setI] = useState<string>('');
  const [r, setR] = useState<string>('');
  const [p, setP] = useState<string>('');

  // Resistor Color State
  const [bands, setBands] = useState(['brown', 'black', 'red', 'gold']);
  
  const colors: Record<string, { val: number; mult: number; tol: string; hex: string }> = {
    black: { val: 0, mult: 1, tol: '±20%', hex: '#000000' },
    brown: { val: 1, mult: 10, tol: '±1%', hex: '#8B4513' },
    red: { val: 2, mult: 100, tol: '±2%', hex: '#FF0000' },
    orange: { val: 3, mult: 1000, tol: '-', hex: '#FFA500' },
    yellow: { val: 4, mult: 10000, tol: '-', hex: '#FFFF00' },
    green: { val: 5, mult: 100000, tol: '±0.5%', hex: '#008000' },
    blue: { val: 6, mult: 1000000, tol: '±0.25%', hex: '#0000FF' },
    violet: { val: 7, mult: 10000000, tol: '±0.1%', hex: '#EE82EE' },
    grey: { val: 8, mult: 100000000, tol: '±0.05%', hex: '#808080' },
    white: { val: 9, mult: 1000000000, tol: '-', hex: '#FFFFFF' },
    gold: { val: -1, mult: 0.1, tol: '±5%', hex: '#FFD700' },
    silver: { val: -1, mult: 0.01, tol: '±10%', hex: '#C0C0C0' },
  };

  const calculateResistorValue = () => {
    const val1 = colors[bands[0]].val;
    const val2 = colors[bands[1]].val;
    const mult = colors[bands[2]].mult;
    return (val1 * 10 + val2) * mult;
  };

  const calculateOhms = () => {
    const voltage = parseFloat(v);
    const current = parseFloat(i);
    const resistance = parseFloat(r);

    if (!isNaN(voltage) && !isNaN(current)) {
      setR((voltage / current).toFixed(2));
      setP((voltage * current).toFixed(2));
    } else if (!isNaN(voltage) && !isNaN(resistance)) {
      setI((voltage / resistance).toFixed(4));
      setP((Math.pow(voltage, 2) / resistance).toFixed(2));
    } else if (!isNaN(current) && !isNaN(resistance)) {
      setV((current * resistance).toFixed(2));
      setP((Math.pow(current, 2) * resistance).toFixed(2));
    }
  };

  const tabs = [
    { id: 'ohms', label: "Ohm's Law", icon: Zap },
    { id: 'resistor', label: 'Color Code', icon: Layers },
  ];

  return (
    <div className="container mx-auto px-6 md:px-8 py-10 md:py-24 relative min-h-screen">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-sky-500/5 blur-[120px] rounded-full pointer-events-none" />
      
      <div className="max-w-5xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-black tracking-tighter text-white"
          >
            Engineering <span className="text-sky-400">Calculators</span>
          </motion.h2>
          <p className="text-slate-400 text-sm md:text-lg font-medium max-w-2xl mx-auto">
            High-precision design utilities for professional circuit synthesis and rapid prototyping.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex flex-wrap justify-center gap-4">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-3 transition-all",
                activeTab === tab.id 
                  ? "bg-sky-500 text-slate-950 shadow-[0_0_20px_rgba(14,165,233,0.3)]" 
                  : "bg-white/5 text-slate-400 border border-white/5 hover:bg-white/10"
              )}
            >
              <tab.icon size={18} />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Main Workspace */}
          <div className="lg:col-span-12 space-y-8">
            <AnimatePresence mode="wait">
              {activeTab === 'ohms' && (
                <motion.div
                  key="ohms"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="grid grid-cols-1 md:grid-cols-2 gap-8"
                >
                  <div className="bg-white/[0.03] backdrop-blur-2xl border border-white/10 rounded-[40px] p-8 md:p-12 shadow-2xl space-y-10">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-sky-500/20 rounded-2xl flex items-center justify-center">
                          <Zap className="text-sky-400" />
                        </div>
                        <div>
                          <h3 className="text-2xl font-black text-white">Ohm's Law</h3>
                          <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Fundamental Synthesis</p>
                        </div>
                      </div>
                      <button onClick={() => { setV(''); setI(''); setR(''); setP(''); }} className="p-3 bg-white/5 rounded-xl text-slate-500 hover:text-white transition-colors">
                        <RefreshCw size={20} />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 gap-6">
                      {[
                        { label: 'Voltage', unit: 'V', state: v, set: setV },
                        { label: 'Current', unit: 'A', state: i, set: setI },
                        { label: 'Resistance', unit: 'Ω', state: r, set: setR },
                      ].map((field) => (
                        <div key={field.label} className="space-y-2">
                          <div className="flex justify-between items-center px-1">
                             <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{field.label} ({field.unit})</label>
                             <span className="text-[10px] font-mono text-sky-500/50">MEASURED</span>
                          </div>
                          <div className="relative group">
                            <input 
                              type="number" 
                              value={field.state}
                              onChange={(e) => field.set(e.target.value)}
                              placeholder={`Enter ${field.label}...`}
                              className="w-full bg-black/40 border border-white/5 rounded-2xl px-6 py-5 text-lg text-white focus:border-sky-500/50 outline-none transition-all group-hover:border-white/10"
                            />
                            <div className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-600 font-bold">{field.unit}</div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <button 
                      onClick={calculateOhms}
                      className="w-full py-5 bg-sky-500 text-slate-950 font-black rounded-2xl shadow-xl shadow-sky-500/20 hover:scale-[1.02] active:scale-98 transition-all flex items-center justify-center gap-3"
                    >
                      <Activity size={20} />
                      Synthesize Results
                    </button>
                  </div>

                  <div className="flex flex-col gap-6">
                    <div className="bg-gradient-to-br from-indigo-500/10 to-sky-500/10 border border-white/5 rounded-[40px] p-8 md:p-12 backdrop-blur-xl group overflow-hidden relative">
                      <div className="absolute -right-8 -top-8 w-32 h-32 bg-sky-500/10 rounded-full blur-3xl group-hover:bg-sky-500/20 transition-colors" />
                      <h4 className="text-xs font-black text-sky-400 uppercase tracking-widest mb-4">Real-Time Power Output</h4>
                      <div className="flex items-baseline gap-4">
                        <div className="text-7xl md:text-8xl font-black text-white tracking-tighter">{p || '0.0'}</div>
                        <div className="text-2xl font-black text-slate-500 uppercase">W</div>
                      </div>
                      <div className="mt-8 flex items-center gap-2 text-slate-500">
                        <Activity className="text-emerald-500 animate-pulse" size={16} />
                        <span className="text-xs font-bold uppercase tracking-widest">Continuous Calculation Active</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-6">
                      <div className="bg-white/5 border border-white/5 p-8 rounded-[40px] backdrop-blur-xl group hover:border-sky-500/20 transition-all">
                        <ShieldCheck className="text-sky-500 mb-4 group-hover:scale-110 transition-transform" size={32} />
                        <div className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-1">Safety Analysis</div>
                        <div className="text-2xl font-black text-white">NOMINAL</div>
                      </div>
                      <div className="bg-white/5 border border-white/5 p-8 rounded-[40px] backdrop-blur-xl group hover:border-indigo-500/20 transition-all">
                        <Calculator className="text-indigo-400 mb-4 group-hover:scale-110 transition-transform" size={32} />
                        <div className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-1">Complexity</div>
                        <div className="text-2xl font-black text-white">CORE-V1</div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'resistor' && (
                <motion.div
                  key="resistor"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-8"
                >
                  <div className="bg-white/[0.03] border border-white/10 rounded-[40px] p-8 md:p-12 backdrop-blur-2xl shadow-2xl">
                    <div className="flex flex-col md:flex-row items-center gap-12">
                      <div className="flex-1 w-full space-y-12">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-sky-500/20 rounded-2xl flex items-center justify-center font-black text-sky-400">R</div>
                          <div>
                            <h3 className="text-2xl font-black text-white tracking-tight">Resistor Color Code</h3>
                            <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Industry Standard Identification</p>
                          </div>
                        </div>

                        <div className="relative h-24 md:h-32 bg-slate-800/50 rounded-3xl border border-white/5 flex items-center justify-center px-12 md:px-24">
                          {/* Resistor Body */}
                          <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-1.5 bg-slate-700/50 -z-10" />
                          <div className="relative w-full h-12 md:h-16 bg-[#eec894] rounded-lg flex justify-between px-8 md:px-12 items-center overflow-hidden border border-amber-900/10">
                            {bands.map((color, idx) => (
                              <motion.div 
                                key={idx}
                                layoutId={`band-${idx}`}
                                className="w-4 md:w-6 h-full shadow-[inset_0_0_10px_rgba(0,0,0,0.1)]"
                                style={{ backgroundColor: colors[color].hex }}
                              />
                            ))}
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          {bands.map((currentBand, bandIdx) => (
                            <div key={bandIdx} className="space-y-3">
                              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-1">
                                {bandIdx === 2 ? 'Multiplier' : bandIdx === 3 ? 'Tolerance' : `Band ${bandIdx + 1}`}
                              </label>
                              <select 
                                value={currentBand}
                                onChange={(e) => {
                                  const newBands = [...bands];
                                  newBands[bandIdx] = e.target.value;
                                  setBands(newBands);
                                }}
                                className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-3 text-xs font-bold text-white outline-none focus:border-sky-500/50"
                              >
                                {Object.keys(colors).map(c => (
                                  <option key={c} value={c} className="bg-slate-900">{c.toUpperCase()}</option>
                                ))}
                              </select>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="w-full md:w-72 space-y-6">
                        <div className="p-10 rounded-[32px] bg-sky-500 border border-sky-400/50 text-slate-950 text-center shadow-xl shadow-sky-500/20">
                           <div className="text-[10px] font-black uppercase tracking-widest mb-1 opacity-60">Resistance Value</div>
                           <div className="text-4xl font-black">{calculateResistorValue().toLocaleString()} Ω</div>
                           <div className="mt-2 text-xs font-bold uppercase tracking-tight">{colors[bands[3]].tol} Tolerance</div>
                        </div>
                        <div className="p-8 rounded-[32px] bg-white/5 border border-white/5 flex items-center justify-between">
                           <span className="text-[10px] font-black text-slate-500 uppercase">Multiplier</span>
                           <span className="text-xl font-bold text-white">x{colors[bands[2]].mult}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
