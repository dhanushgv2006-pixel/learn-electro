import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Play, Zap, Cpu, Thermometer, Layers, GraduationCap } from 'lucide-react';
import CircuitBackground from '../ui/CircuitBackground';

interface HeroProps {
  onExplore: (section: string) => void;
}

export default function Hero({ onExplore }: HeroProps) {
  return (
    <section className="relative container mx-auto px-6 md:px-8 py-10 md:py-16 lg:py-24 flex flex-col lg:flex-row items-center gap-10 md:gap-16 overflow-hidden min-h-[calc(100vh-64px)] md:min-h-[calc(100vh-80px)]">
      <CircuitBackground />

      {/* Content Column */}
      <div className="flex-1 flex flex-col justify-center space-y-6 md:space-y-8 max-w-[650px] w-full z-10">
        <div className="space-y-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-sky-500/10 border border-sky-500/20 text-sky-400 text-[10px] md:text-xs font-bold uppercase tracking-wider backdrop-blur-md"
          >
            <span className="w-2 h-2 rounded-full bg-sky-500 animate-pulse"></span>
            Professional Engineering Platform
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-7xl lg:text-8xl font-black leading-[1.05] tracking-tighter text-white"
          >
            Learn Electronic <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-indigo-400">Components</span>
          </motion.h1>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <p className="text-slate-400 text-sm md:text-xl leading-relaxed max-w-[500px] mb-6">
              Master theory, symbols, and real-world application through high-fidelity simulations and deep technical data.
            </p>
            
            <div className="flex items-center gap-3 p-4 bg-sky-500/10 border border-sky-500/20 rounded-2xl mb-8">
              <div className="w-10 h-10 rounded-full bg-sky-500/20 flex items-center justify-center shrink-0">
                <GraduationCap className="text-sky-400" size={20} />
              </div>
              <p className="text-sky-400 font-bold text-sm md:text-lg tracking-tight leading-snug">
                This website is created by S4 batch for EC Department 'S' section
              </p>
            </div>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex flex-wrap items-center gap-4"
        >
          <button 
            onClick={() => onExplore('lab')}
            className="flex-1 sm:flex-none px-8 md:px-10 py-4 md:py-5 bg-sky-500 text-slate-950 font-black rounded-xl md:rounded-2xl shadow-[0_0_40px_rgba(14,165,233,0.4)] hover:scale-105 transition-all active:scale-95 flex items-center gap-2 group"
          >
            Launch Virtual Lab
            <Play size={18} className="fill-current group-hover:translate-x-1 transition-transform" />
          </button>
          <button 
            onClick={() => onExplore('components')}
            className="flex-1 sm:flex-none px-8 md:px-10 py-4 md:py-5 bg-white/5 border border-white/10 backdrop-blur-xl text-white font-black rounded-xl md:rounded-2xl hover:bg-white/10 transition-all flex items-center justify-center gap-2 border-gradient"
          >
            Explore Library
            <ArrowRight className="w-5 h-5 text-sky-400" />
          </button>
        </motion.div>

        {/* Professional Stats Section */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-10"
        >
          {[
            { label: 'Components', val: '120+', icon: Layers },
            { label: 'Calculators', val: '25+', icon: Cpu },
            { label: 'Virtual Labs', val: '15', icon: Zap },
            { label: 'Tests', val: '50+', icon: Thermometer },
          ].map((stat, i) => (
            <div key={i} className="group relative p-4 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-md hover:border-sky-500/30 transition-all">
              <div className="absolute inset-0 bg-sky-500/0 group-hover:bg-sky-500/5 transition-colors rounded-2xl" />
              <stat.icon size={16} className="text-sky-500/60 mb-2 group-hover:text-sky-400 transition-colors" />
              <div className="text-xl md:text-2xl font-black text-white">{stat.val}</div>
              <div className="text-[10px] text-slate-500 uppercase tracking-widest font-black group-hover:text-slate-400">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Visual Column (Simulation Card) */}
      <div className="hidden sm:block flex-1 relative w-full max-w-[500px]">
        <div className="bg-slate-900/50 backdrop-blur-2xl border border-white/10 rounded-[40px] p-10 shadow-2xl relative z-10 overflow-hidden group">
          <div className="absolute top-0 right-0 p-6">
            <div className="px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 text-[10px] font-bold uppercase tracking-wider backdrop-blur-md">
              Live Simulation
            </div>
          </div>
          
          <div className="mb-12">
            <h3 className="text-sky-400 text-xs font-bold uppercase tracking-widest mb-2 flex items-center gap-2">
              <Zap className="w-4 h-4 fill-sky-400" />
              Active Module
            </h3>
            <h2 className="text-3xl font-black text-white">N-Channel MOSFET</h2>
            <p className="text-slate-500 text-sm mt-1">IRFZ44N / Switching Characteristics</p>
          </div>

          <div className="flex flex-col items-center justify-center space-y-10 py-4">
            <div className="w-56 h-56 border border-white/10 rounded-full flex items-center justify-center relative bg-white/[0.02]">
              <div className="absolute inset-0 rounded-full border border-sky-500/20 animate-pulse opacity-40 scale-110"></div>
              <div className="w-36 h-36 border-4 border-sky-400/30 bg-sky-500/5 rounded-2xl flex items-center justify-center shadow-inner">
                 <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" strokeWidth="1.5" className="drop-shadow-[0_0_10px_rgba(56,189,248,0.5)]">
                  <path d="M7 4V20M17 4V20M7 12H17M10 8L7 12L10 16M14 8L17 12L14 16" />
                </svg>
              </div>
              <div className="absolute -bottom-3 px-4 py-1.5 bg-sky-500 text-slate-950 text-[11px] font-black rounded-full shadow-lg shadow-sky-500/40">
                SYMBOL VIEW
              </div>
            </div>
            
            <div className="w-full space-y-5">
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-bold uppercase tracking-wider">
                  <span className="text-slate-500">Gate Voltage (Vgs)</span>
                  <span className="text-sky-400">4.5V</span>
                </div>
                <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: '45%' }}
                    transition={{ duration: 2, ease: "easeOut" }}
                    className="h-full bg-sky-500 shadow-[0_0_15px_#0ea5e9]"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-bold uppercase tracking-wider">
                  <span className="text-slate-500">Drain Current (Id)</span>
                  <span className="text-white">12.4A</span>
                </div>
                <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: '75%' }}
                    transition={{ duration: 2, delay: 0.5, ease: "easeOut" }}
                    className="h-full bg-sky-400"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Decorative Blurs */}
        <div className="absolute -right-16 top-1/4 w-64 h-64 bg-sky-500/20 blur-[120px] rounded-full -z-10"></div>
        <div className="absolute -left-16 bottom-1/4 w-64 h-64 bg-indigo-500/20 blur-[120px] rounded-full -z-10"></div>
      </div>

      {/* Marquee Banner - Optimized for mobile */}
      <div className="absolute bottom-0 left-0 w-full overflow-hidden whitespace-nowrap border-t border-white/5 py-3 md:py-4 bg-slate-950/60 backdrop-blur-sm z-20">
        <div className="flex animate-marquee">
          {[...Array(6)].map((_, i) => (
            <span key={i} className="text-sky-500/60 font-mono text-[10px] md:text-sm tracking-widest uppercase mx-12 shrink-0">
              CREATED BY BABUJI INSTITUTE OF ENGINEERING AND TECHNOLOGY COLLEGE STUDENT
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
