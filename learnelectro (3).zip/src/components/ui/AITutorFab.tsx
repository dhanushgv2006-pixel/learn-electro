import React, { useState } from 'react';
import { Bot } from 'lucide-react';
import { motion } from 'motion/react';
import AITutorModal from './AITutorModal';

export default function AITutorFab() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <div className="fixed bottom-12 right-8 z-[100] group">
        <motion.div 
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 rounded-2xl bg-sky-500 shadow-[0_0_25px_rgba(14,165,233,0.5)] flex items-center justify-center cursor-pointer relative"
        >
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-[#020617] rounded-full shadow-lg shadow-emerald-500/20"></div>
          <Bot className="w-8 h-8 text-slate-950" />
          
          {/* Tooltip */}
          <div className="absolute right-20 bg-slate-900 border border-white/10 px-4 py-2 rounded-xl text-xs font-bold text-white whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-2xl">
            AI Tutor Online
          </div>
        </motion.div>
      </div>

      <AITutorModal isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </>
  );
}
