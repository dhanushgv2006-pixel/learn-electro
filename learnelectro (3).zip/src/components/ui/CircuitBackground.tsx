import React from 'react';
import { motion } from 'motion/react';

export default function CircuitBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none -z-20">
      {/* Grid Pattern */}
      <div 
        className="absolute inset-0 opacity-[0.03]" 
        style={{ 
          backgroundImage: `linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)`,
          backgroundSize: '40px 40px'
        }}
      />
      
      {/* Animated Circuit Lines */}
      <svg className="absolute inset-0 w-full h-full">
        <defs>
          <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="transparent" />
            <stop offset="50%" stopColor="rgba(14, 165, 233, 0.2)" />
            <stop offset="100%" stopColor="transparent" />
          </linearGradient>
          
          <filter id="glow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Vertical Lines */}
        {[...Array(8)].map((_, i) => (
          <motion.path
            key={`v-${i}`}
            d={`M ${10 + i * 15}% 0 L ${10 + i * 15}% 100`}
            stroke="url(#lineGradient)"
            strokeWidth="1"
            fill="none"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ 
              pathLength: [0, 1, 0], 
              opacity: [0, 1, 0],
              y: [-100, 100]
            }}
            transition={{ 
              duration: 8, 
              repeat: Infinity, 
              delay: i * 1.5,
              ease: "linear"
            }}
          />
        ))}

        {/* Horizontal Lines */}
        {[...Array(6)].map((_, i) => (
          <motion.path
            key={`h-${i}`}
            d={`M 0 ${20 + i * 15}% L 100% ${20 + i * 15}%`}
            stroke="url(#lineGradient)"
            strokeWidth="1"
            fill="none"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ 
              pathLength: [0, 1, 0], 
              opacity: [0, 1, 0],
              x: [-100, 100]
            }}
            transition={{ 
              duration: 10, 
              repeat: Infinity, 
              delay: i * 2,
              ease: "linear"
            }}
          />
        ))}

        {/* Circuit Junctions */}
        {[...Array(12)].map((_, i) => (
          <motion.circle
            key={`c-${i}`}
            cx={`${Math.random() * 100}%`}
            cy={`${Math.random() * 100}%`}
            r="2"
            fill="#0ea5e9"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ 
              opacity: [0, 0.5, 0],
              scale: [0, 1.5, 0]
            }}
            transition={{ 
              duration: 3, 
              repeat: Infinity, 
              delay: i * 1,
            }}
            filter="url(#glow)"
          />
        ))}
      </svg>

      {/* Radial Gradient Glows */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-sky-500/5 rounded-full blur-[100px]" />
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-indigo-500/5 rounded-full blur-[100px]" />
    </div>
  );
}
