import React from 'react';
import { Cpu, Github, Instagram, Youtube, Twitter, Linkedin, Mail, MapPin } from 'lucide-react';
import { motion } from 'motion/react';

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-slate-950 pt-20 pb-10">
      <div className="container mx-auto px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          {/* Brand Section */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-sky-500 rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(14,165,233,0.3)]">
                <Cpu className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-black tracking-tight text-white">
                Learn<span className="text-sky-400">Electro</span>
              </span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed">
              Empowering the next generation of EC engineers through high-fidelity simulations, interactive tools, and comprehensive technical data.
            </p>
            <div className="flex items-center gap-4 text-slate-500">
              <motion.a whileHover={{ y: -2, color: '#fff' }} href="#"><Github size={20} /></motion.a>
              <motion.a whileHover={{ y: -2, color: '#0ea5e9' }} href="#"><Twitter size={20} /></motion.a>
              <motion.a whileHover={{ y: -2, color: '#0ea5e9' }} href="#"><Linkedin size={20} /></motion.a>
              <motion.a whileHover={{ y: -2, color: '#e11d48' }} href="#"><Youtube size={20} /></motion.a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-black uppercase tracking-widest text-xs mb-6">Navigation</h4>
            <ul className="space-y-4">
              {['Dashboard', 'Components', 'Virtual Lab', 'Calculators', 'Quiz'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-slate-500 hover:text-sky-400 transition-colors text-sm font-bold uppercase tracking-tight">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact & Support */}
          <div>
            <h4 className="text-white font-black uppercase tracking-widest text-xs mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 text-slate-500 text-sm font-medium">
                <Mail size={16} className="text-sky-500" />
                support@learnelectro.edu
              </li>
              <li className="flex items-center gap-3 text-slate-500 text-sm font-medium">
                <MapPin size={16} className="text-sky-500" />
                EC Department, Block S
              </li>
            </ul>
          </div>

          {/* College Branding */}
          <div className="p-6 rounded-[32px] bg-white/[0.03] border border-white/5 relative overflow-hidden group">
            <div className="absolute -right-4 -top-4 w-24 h-24 bg-sky-500/10 rounded-full blur-2xl group-hover:bg-sky-500/20 transition-colors" />
            <h4 className="text-xs font-black text-sky-400 uppercase tracking-widest mb-4">Official Project</h4>
            <p className="text-white font-black text-lg mb-2">S4 Batch - Section S</p>
            <p className="text-slate-500 text-xs font-bold leading-relaxed mb-4">
              EC Department, Engineering College Campus
            </p>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase">
              Approved v1.0
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 text-[10px] font-black text-slate-500 uppercase tracking-widest text-center md:text-left">
            <span>© 2026 LearnElectro. Created by Dhanush G V & Team. All Rights Reserved.</span>
          </div>
          <div className="flex gap-8 text-[10px] font-black text-slate-500 uppercase tracking-widest">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Feedback</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
