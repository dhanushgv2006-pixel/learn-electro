import React, { useState } from 'react';
import { Cpu, Menu, X, ChevronRight, Search, Command } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  activeSection: string;
  setActiveSection: (s: string) => void;
  onSearch: (q: string) => void;
}

export default function Navbar({ activeSection, setActiveSection, onSearch }: NavbarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { name: 'Dashboard', id: 'home' },
    { name: 'Components', id: 'components' },
    { name: 'Virtual Lab', id: 'lab' },
    { name: 'Calculators', id: 'tools' },
    { name: 'Quiz', id: 'quiz' },
  ];

  const handleNavClick = (id: string) => {
    setActiveSection(id);
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav className="h-16 md:h-20 border-b border-white/5 backdrop-blur-2xl bg-slate-950/70 flex items-center justify-between px-6 md:px-12 z-[100] sticky top-0">
        <div 
          className="flex items-center gap-3 cursor-pointer z-[110]"
          onClick={() => handleNavClick('home')}
        >
          <div className="w-8 h-8 md:w-10 md:h-10 bg-sky-500 rounded-lg flex items-center justify-center shadow-[0_0_20px_rgba(14,165,233,0.4)]">
            <Cpu className="w-5 h-5 md:w-6 md:h-6 text-white" />
          </div>
          <span className="text-lg md:text-2xl font-black tracking-tight text-white">
            Learn<span className="text-sky-400">Electro</span>
          </span>
        </div>

        {/* Search Bar (Centered on Desktop) */}
        <div className="hidden lg:flex flex-1 max-w-md mx-8">
          <div className="relative w-full group">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={16} className="text-slate-500 group-focus-within:text-sky-400 transition-colors" />
            </div>
            <input 
              type="text"
              placeholder="Quick search components..."
              onChange={(e) => onSearch(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-10 pr-12 text-sm text-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500/50 focus:bg-white/10 transition-all"
            />
            <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none">
              <div className="flex items-center gap-1 px-1.5 py-0.5 rounded border border-white/10 bg-white/5 text-[10px] text-slate-500 font-mono">
                <Command size={10} />
                <span>K</span>
              </div>
            </div>
          </div>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          <div className="flex items-center gap-6 text-sm font-black text-slate-400">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`transition-all hover:text-white relative py-2 uppercase tracking-widest text-[11px] ${activeSection === item.id ? 'text-sky-400' : ''}`}
              >
                {item.name}
                {activeSection === item.id && (
                  <motion.div 
                    layoutId="activeTab"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-sky-500 rounded-full shadow-[0_0_10px_#0ea5e9]"
                  />
                )}
              </button>
            ))}
          </div>
          <div className="h-6 w-[1px] bg-white/10"></div>
          <div className="flex items-center gap-4 text-sm group cursor-pointer">
            <div className="flex flex-col items-end mr-1 hidden lg:flex">
              <span className="text-white font-bold text-xs uppercase">Dhanush G V</span>
              <span className="text-[10px] text-sky-500/70 font-mono">ENG. STUDENT</span>
            </div>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-sky-500 to-indigo-600 border-2 border-white/20 p-1 group-hover:scale-110 transition-transform">
              <div className="w-full h-full rounded-full bg-slate-900 border border-white/10 flex items-center justify-center">
                <span className="text-[10px] font-black">DG</span>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Menu Toggle */}
        <div className="flex items-center gap-4 md:hidden">
          <button className="p-2 text-slate-400">
            <Search size={20} />
          </button>
          <button 
            className="z-[110] p-2 text-white bg-white/5 rounded-lg border border-white/10"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-[90] bg-slate-950 pt-24 px-6 md:hidden"
          >
            <div className="flex flex-col gap-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center justify-between p-4 rounded-2xl border border-white/5 transition-all
                    ${activeSection === item.id ? 'bg-sky-500/10 border-sky-500/20 text-sky-400' : 'bg-white/5 text-slate-400'}
                  `}
                >
                  <span className="text-lg font-bold">{item.name}</span>
                  <ChevronRight className={`w-5 h-5 ${activeSection === item.id ? 'text-sky-400' : 'text-slate-600'}`} />
                </button>
              ))}
            </div>

            <div className="mt-8 p-6 rounded-3xl bg-gradient-to-br from-sky-500/10 to-indigo-500/10 border border-white/10">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-sky-500 flex items-center justify-center font-bold text-slate-950">
                  JD
                </div>
                <div>
                  <div className="text-white font-bold text-sm">Engineering Student</div>
                  <div className="text-slate-500 text-xs">S4 Batch - Section S</div>
                </div>
              </div>
              <button className="w-full py-3 bg-white/5 hover:bg-white/10 rounded-xl text-white text-sm font-bold transition-colors">
                View Profile
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
