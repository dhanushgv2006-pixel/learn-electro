export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number; // Index of options
  explanation: string;
}

export const quizQuestions: Question[] = [
  {
    id: 1,
    question: "Which component is used to limit current in a circuit?",
    options: ["Capacitor", "Inductor", "Resistor", "Diode"],
    correctAnswer: 2,
    explanation: "A resistor limits the flow of electrical current based on Ohm's Law (V=IR)."
  },
  {
    id: 2,
    question: "What happens to the resistance of a standard conductor as its temperature increases?",
    options: ["Decreases", "Increases", "Stays the same", "Becomes zero"],
    correctAnswer: 1,
    explanation: "Most conductors have a Positive Temperature Coefficient (PTC), meaning resistance increases with temperature."
  },
  {
    id: 3,
    question: "Which component stores energy in a magnetic field?",
    options: ["Capacitor", "Resistor", "Inductor", "Battery"],
    correctAnswer: 2,
    explanation: "Inductors store energy in a magnetic field when current flows through them."
  },
  {
    id: 4,
    question: "What is the primary function of a Zener diode in a circuit?",
    options: ["Amplification", "Rectification", "Voltage Regulation", "Oscillation"],
    correctAnswer: 2,
    explanation: "Zener diodes are specifically designed to provide a stable reference voltage for regulation."
  },
  {
    id: 5,
    question: "Which terminal of a MOSFET controls the channel conductivity?",
    options: ["Source", "Drain", "Gate", "Base"],
    correctAnswer: 2,
    explanation: "The Gate terminal is used to control the electric field that modulates the channel."
  },
  {
    id: 6,
    question: "What type of device is a BJT (Bipolar Junction Transistor)?",
    options: ["Voltage-controlled", "Current-controlled", "Power-controlled", "Flux-controlled"],
    correctAnswer: 1,
    explanation: "A BJT is a current-controlled device where a small base current controls a larger collector current."
  },
  {
    id: 7,
    question: "In an ideal Op-Amp, what is the input impedance?",
    options: ["Zero", "100 Ohms", "1k Ohms", "Infinite"],
    correctAnswer: 3,
    explanation: "An ideal operational amplifier is assumed to have infinite input impedance so that it draws no current from the source."
  },
  {
    id: 8,
    question: "What is the standard forward voltage drop for a Silicon diode?",
    options: ["0.3V", "0.7V", "1.1V", "2.0V"],
    correctAnswer: 1,
    explanation: "Silicon diodes typically have a forward voltage drop of approximately 0.7V."
  },
  {
    id: 9,
    question: "Which unit is used to measure inductance?",
    options: ["Farad", "Henry", "Tesla", "Ohm"],
    correctAnswer: 1,
    explanation: "Inductance is measured in Henrys (H)."
  },
  {
    id: 10,
    question: "What does 'LED' stand for?",
    options: ["Light Electronic Device", "Low Energy Diode", "Light Emitting Diode", "Laser Emitting Device"],
    correctAnswer: 2,
    explanation: "LED stands for Light Emitting Diode."
  }
];
