import { ElectronicComponent } from '../types';

export const electronicComponents: ElectronicComponent[] = [
  {
    id: 'resistor',
    name: 'Resistor',
    category: 'Passive',
    description: 'A passive two-terminal electrical component that implements electrical resistance as a circuit element.',
    symbol: 'R',
    image: '/src/assets/images/regenerated_image_1779105508677.jpg',
    working: 'In electronic circuits, resistors are used to reduce current flow, adjust signal levels, to divide voltages, bias active elements, and terminate transmission lines.',
    formula: 'V = I × R (Ohm\'s Law)',
    applications: ['Current limiting', 'Voltage division', 'Pull-up/Pull-down', 'Biasing'],
    advantages: ['Inexpensive', 'Compact', 'Reliable', 'No power source needed'],
    disadvantages: ['Generates heat', 'Fixed value (mostly)', 'Power limitations'],
    revisionNotes: [
      'Resistance is directly proportional to length and inversely proportional to cross-sectional area.',
      'Ohm\'s Law: V = IR is valid only if temperature and other physical conditions remain constant.',
      'Tolerance determines the precision; lower tolerance means higher precision.',
      'In Series: Rt = R1 + R2 + ...',
      'In Parallel: 1/Rt = 1/R1 + 1/R2 + ...'
    ],
    interviewQuestions: [
      { q: 'What is a resistor?', a: 'A component that limits the flow of electrical current.' },
      { q: 'How does temperature affect resistance?', a: 'For most conductors, resistance increases with temperature (Positive Temperature Coefficient).' },
      { q: 'What is the color code for a 1k Ohm resistor?', a: 'Brown, Black, Red, Gold (assuming 5% tolerance).' }
    ],
    circuitExamples: [
      {
        id: 'voltage-divider',
        title: 'Simple Voltage Divider',
        diagram: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=600',
        description: 'Two resistors in series divide the input voltage into a smaller output voltage.',
        parts: [
          { id: 'r1', name: 'Resistor R1', explanation: 'Current limiting resistor at the input side.', position: { x: 30, y: 40 } },
          { id: 'r2', name: 'Resistor R2', explanation: 'Output side resistor forming the divider ratio.', position: { x: 70, y: 40 } }
        ],
        simulationResult: 'Vout = Vin * (R2 / (R1 + R2)). For R1=R2, Vout is half of Vin.'
      }
    ]
  },
  {
    id: 'capacitor',
    name: 'Capacitor',
    category: 'Passive',
    description: 'A device that stores electrical energy in an electric field.',
    symbol: 'C',
    image: '/src/assets/images/regenerated_image_1779105700528.png',
    working: 'Consists of two conducting plates separated by an insulating material called the dielectric. When voltage is applied, charges accumulate on the plates.',
    formula: 'Q = C × V ; Xc = 1 / (2πfC)',
    applications: ['Filtering', 'Energy storage', 'Coupling/Decoupling', 'Timing circuits'],
    advantages: ['Fast discharge', 'Long life', 'High efficiency'],
    disadvantages: ['Low energy density', 'Voltage limits', 'Leakage current'],
    revisionNotes: [
      'Capacitance is proportional to plate area and inversely proportional to distance between plates.',
      'Dielectric constant determines the ratio of capacitance with the material vs vacuum.',
      'Time Constant (τ): τ = R × C. A capacitor is 99% charged after 5τ.',
      'In Series: 1/Ct = 1/C1 + 1/C2 + ...',
      'In Parallel: Ct = C1 + C2 + ...'
    ],
    interviewQuestions: [
      { q: 'What is capacitance?', a: 'The ability of a component to collect and store energy in the form of an electrical charge.' },
      { q: 'Why do we use decoupling capacitors?', a: 'To filter out high-frequency noise from power supply lines and provide local energy storage.' },
      { q: 'What happens to a capacitor in a DC circuit?', a: 'It acts as an open circuit once fully charged.' }
    ],
    circuitExamples: [
      {
        id: 'smoothing-filter',
        title: 'Power Supply Smoothing',
        diagram: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=600',
        description: 'Capacitors smooth out voltage ripples in basic power supply rectified outputs.',
        parts: [
          { id: 'cap', name: 'Electrolytic Capacitor', explanation: 'Stores charge to fill in gaps during AC ripple dips.', position: { x: 50, y: 50 } }
        ],
        simulationResult: 'Reduces peak-to-peak ripple voltage significantly depending on capacitance value.'
      }
    ]
  },
  {
    id: 'inductor',
    name: 'Inductor',
    category: 'Passive',
    description: 'A passive two-terminal electrical component that stores energy in a magnetic field when electric current flows through it.',
    symbol: 'L',
    image: '/src/assets/images/regenerated_image_1779105782502.webp',
    working: 'When current flows through the coil, a magnetic field is created. Changes in current induce a counter-electromotive force (Lenz\'s Law) that opposes the change.',
    formula: 'V = L × (di/dt) ; Xl = 2πfL',
    applications: ['RF tuning', 'Filters', 'Transformers', 'Energy storage in switching regulators'],
    advantages: ['Stores magnetic energy', 'Good for high-frequency filtering'],
    disadvantages: ['Bulky', 'Can emit EMI', 'Susceptible to external magnetic fields'],
    interviewQuestions: [
      { q: 'What is Inductance?', a: 'The property of an electrical conductor by which a change in current through it induces an electromotive force (EMF).' },
      { q: 'What is the role of the core in an inductor?', a: 'The core increases the magnetic flux density, thereby increasing the inductance value.' }
    ]
  },
  {
    id: 'variable-resistor',
    name: 'Variable Resistor',
    category: 'Passive',
    description: 'Resistance can be adjusted manually. Used in volume controls and tuning circuits.',
    symbol: 'RV',
    image: '/src/assets/images/regenerated_image_1779106000774.webp',
    working: 'Uses a sliding contact (wiper) along a resistive element to vary resistance between two terminals.',
    applications: ['Volume control', 'Brightness adjustment', 'Tuning'],
    advantages: ['Adjustable', 'Versatile'],
    disadvantages: ['Mechanical wear', 'Noise during adjustment'],
    interviewQuestions: [
      { q: 'What is a potentiometer?', a: 'A three-terminal variable resistor used as a voltage divider.' }
    ]
  },
  {
    id: 'thermistor',
    name: 'Thermistor',
    category: 'Passive',
    description: 'Resistance changes with temperature variation. Used in temperature sensing and battery protection.',
    symbol: 'RT',
    image: '/src/assets/images/regenerated_image_1779186013051.jpg',
    working: 'A type of resistor whose resistance is dependent on temperature, more so than in standard resistors.',
    applications: ['Temperature sensing', 'Over-current protection', 'Battery thermal monitoring'],
    advantages: ['Highly sensitive', 'Compact', 'Fast response'],
    disadvantages: ['Non-linear', 'Limited temperature range'],
    interviewQuestions: [
      { q: 'NTC vs PTC?', a: 'NTC resistance decreases with temperature; PTC resistance increases.' }
    ]
  },
  {
    id: 'ldr-resistor',
    name: 'LDR Resistor',
    category: 'Passive',
    description: 'Special resistor whose resistance changes with light intensity. Used in automatic lighting systems.',
    symbol: 'LDR',
    image: '/src/assets/images/regenerated_image_1779107335745.jpg',
    working: 'Uses cadmium sulfide (CdS) which decreases its resistance as light intensity increases.',
    applications: ['Automatic lamps', 'Light meters', 'Fire alarms'],
    advantages: ['Inexpensive', 'Simple to use'],
    disadvantages: ['Slow response', 'Affected by ambient light'],
    interviewQuestions: [
      { q: 'What material is used in LDR?', a: 'Cadmium Sulfide (CdS) is the most common material.' }
    ]
  },
  {
    id: 'diode',
    name: 'Diode',
    category: 'Semiconductor',
    description: 'A two-terminal electronic component that conducts current primarily in one direction.',
    symbol: 'D',
    image: '/src/assets/images/regenerated_image_1779186010518.jpg',
    working: 'A PN junction that allows current to flow when forward biased (anode more positive than cathode) and blocks current when reverse biased.',
    formula: 'Vf ≈ 0.7V for Silicon',
    applications: ['Rectification (AC to DC)', 'Signal clipping', 'Clamping', 'Reverse polarity protection'],
    advantages: ['Simple rectifier', 'High reliability', 'Low cost'],
    disadvantages: ['Voltage drop', 'Leakage current', 'Breakdown at high reverse voltage'],
    interviewQuestions: [
      { q: 'What is P-N junction?', a: 'The boundary or interface between two types of semiconductor material (p-type and n-type).' },
      { q: 'What is the depletion region?', a: 'An insulating layer within a p-n junction where mobile charge carriers have been diffused or forced away.' }
    ]
  },
  {
    id: 'bjt-transistor',
    name: 'BJT Transistor',
    category: 'Semiconductor',
    description: 'A type of transistor that uses both electron and hole charge carriers.',
    symbol: 'Q',
    image: '/src/assets/images/regenerated_image_1779186009804.webp',
    working: 'Uses a small current at the base terminal to control a much larger current between the collector and emitter terminals.',
    formula: 'Ic = β × Ib',
    applications: ['Switching', 'Amplification', 'Current source', 'Voltage regulation'],
    advantages: ['High gain', 'Fast switching', 'Excellent linear amplifier'],
    disadvantages: ['Thermal instability', 'Current controlled device', 'Requires continuous base current'],
    interviewQuestions: [
      { q: 'What are the three terminals of BJT?', a: 'Emitter, Base, and Collector.' },
      { q: 'What is the active region?', a: 'The region where the base-emitter junction is forward-biased and base-collector is reverse-biased, allowing amplification.' },
      { q: 'Difference between NPN and PNP?', a: 'In NPN, current flows from collector to emitter when base is high. In PNP, it flows from emitter to collector when base is low.' }
    ],
    circuitExamples: [
      {
        id: 'bjt-switch',
        title: 'BJT as a Logic Switch',
        diagram: 'https://images.unsplash.com/photo-1591405351990-4726e331f141?auto=format&fit=crop&q=80&w=600',
        description: 'Using a small base current to switch a larger current through a load like an LED or relay.',
        parts: [
          { id: 'base', name: 'Base Resistor', explanation: 'Protects the base-emitter junction from excessive current.', position: { x: 20, y: 50 } },
          { id: 'bjt', name: 'NPN Transistor', explanation: 'The switching element that conducts when base is biased.', position: { x: 50, y: 50 } },
          { id: 'load', name: 'Load (LED)', explanation: 'The device being switched on/off by the transistor.', position: { x: 80, y: 50 } }
        ],
        simulationResult: 'When base voltage > 0.7V, collector current flows and load turns ON.'
      }
    ]
  },
  {
    id: 'mosfet',
    name: 'MOSFET',
    category: 'Semiconductor',
    description: 'Metal-Oxide-Semiconductor Field-Effect Transistor, used for switching and amplifying signals.',
    symbol: 'M',
    image: '/src/assets/images/regenerated_image_1779186008761.jpg',
    working: 'A voltage-controlled device where an electric field at the gate terminal controls the conductivity of a channel between source and drain.',
    formula: 'Voltage controlled',
    applications: ['Power switching', 'Microprocessors', 'Motor control', 'Inverters'],
    advantages: ['High input impedance', 'Very fast switching', 'Voltage controlled'],
    disadvantages: ['Fragile gate oxide (Static sensitivity)', 'Higher RON at high voltages'],
    interviewQuestions: [
      { q: 'What are the terminals of a MOSFET?', a: 'Gate, Source, and Drain.' },
      { q: 'Why do MOSFETs have high input impedance?', a: 'The gate is insulated from the channel by a thin layer of silicon dioxide (SiO2).' }
    ]
  },
  {
    id: 'led',
    name: 'LED',
    category: 'Semiconductor',
    description: 'Light Emitting Diode, a semiconductor source that emits light when current flows through it.',
    symbol: 'LED',
    image: '/src/assets/images/regenerated_image_1779107338925.webp',
    working: 'Electrons in the semiconductor recombine with electron holes, releasing energy in the form of photons (electroluminescence).',
    formula: 'R = (Vsupply - Vled) / Iled',
    applications: ['Indication', 'Lighting', 'Data transmission (Fiber)', 'Displays'],
    advantages: ['Low power', 'Long life', 'Fast response', 'Compact'],
    disadvantages: ['Sensitive to voltage spikes', 'Requires current limiting', 'Heat management in high power'],
    interviewQuestions: [
      { q: 'Why is a resistor needed with an LED?', a: 'To limit the current and prevent the LED from burning out due to its low internal resistance.' },
      { q: 'What determines the color of an LED?', a: 'The material used in the semiconductor (the bandgap energy).' }
    ],
    circuitExamples: [
      {
        id: 'led-indicator',
        title: 'LED Indicator Circuit',
        diagram: 'https://images.unsplash.com/photo-1542744095-2918eebecdd4?q=80&w=600&auto=format&fit=crop',
        description: 'A basic circuit using a resistor to safely light up an LED from a 5V source.',
        parts: [
          { id: 'res', name: 'Current Limiter', explanation: 'Resistor protecting the LED from high current.', position: { x: 30, y: 50 } },
          { id: 'led', name: 'LED', explanation: 'The light-emitting diode converts electricity to photons.', position: { x: 70, y: 50 } }
        ],
        simulationResult: 'Resistor value should be (5V - 1.8V) / 0.02A = 160 Ohms for a standard red LED.'
      }
    ]
  },
  {
    id: 'zener-diode',
    name: 'Zener Diode',
    category: 'Semiconductor',
    description: 'A special type of diode that allows current to flow in the reverse direction when a specific reverse voltage is reached.',
    symbol: 'ZD',
    image: '/src/assets/images/regenerated_image_1779186006906.png',
    working: 'Designed to operate in its breakdown region (Zener breakdown or Avalanche breakdown) safely, providing a stable reference voltage.',
    formula: 'Vz (Fixed Breakdown Voltage)',
    applications: ['Voltage regulation', 'Surge protection', 'Reference voltage levels'],
    advantages: ['Stable voltage reference', 'Compact', 'Fast reaction'],
    disadvantages: ['Higher leakage than regular diodes', 'Power dissipation limits'],
    interviewQuestions: [
      { q: 'What is Zener Voltage?', a: 'The specific reverse voltage at which the diode starts conducting in reverse bias.' },
      { q: 'How is a Zener diode used as a regulator?', a: 'It is placed in parallel with the load in reverse bias to maintain a constant voltage.' }
    ]
  },
  {
    id: 'op-amp',
    name: 'Op-Amp',
    category: 'IC',
    description: 'A high-gain electronic voltage amplifier with a differential input.',
    symbol: 'U',
    image: '/src/assets/images/regenerated_image_1779107341144.webp',
    working: 'Amplifies the difference between its two input terminals. Used with negative feedback to perform mathematical operations.',
    formula: 'Vout = Aol × (V+ - V-)',
    applications: ['Signal conditioning', 'Mathematics (Addition, Subtraction)', 'Active filters', 'Comparators'],
    advantages: ['Extremely high gain', 'Incredibly versatile', 'Standardized pinouts'],
    disadvantages: ['Requires dual power supply often', 'Bandwidth limitations', 'Output current limits'],
    interviewQuestions: [
      { q: 'What are the characteristics of an Ideal Op-Amp?', a: 'Infinite gain, infinite input impedance, zero output impedance, and infinite bandwidth.' },
      { q: 'What is Virtual Ground?', a: 'A concept in op-amp circuits where the potential at a node is zero despite not being physically connected to ground.' }
    ]
  },

  {
    id: 'arduino-uno',
    name: 'Arduino UNO',
    category: 'IC',
    description: 'Based on the ATmega328P microcontroller and very beginner friendly. Used in robotics, automation, and student prototype projects.',
    symbol: 'UNO',
    image: '/src/assets/images/regenerated_image_1779186003754.webp',
    working: 'Integrates an ATmega chip with USB-serial communication, power regulation, and standard headers for expansion boards (shields).',
    applications: ['Robotics', 'Prototyping', 'Art installations', 'DIY projects'],
    advantages: ['Huge community', 'Simple IDE', 'Robust design'],
    disadvantages: ['Low processing power', 'Limited GPIOs', 'Large form factor'],
    interviewQuestions: [
      { q: 'What is the chip on Arduino UNO?', a: 'ATmega328P.' }
    ]
  },
  {
    id: 'esp32',
    name: 'ESP32',
    category: 'IC',
    description: 'Powerful dual-core microcontroller with built-in WiFi and Bluetooth. Excellent for IoT, smart home, and wireless monitoring systems.',
    symbol: 'ESP',
    image: '/src/assets/images/regenerated_image_1779185971436.png',
    working: 'A low-power system-on-chip with integrated antenna switches, RF balun, and low-noise receive amplifier.',
    applications: ['Smart Home', 'IoT Gateway', 'Wireless audio', 'Data logging'],
    advantages: ['Dual-core performance', 'WiFi/BT integrated', 'Low power modes'],
    disadvantages: ['Complexity', 'High power during transmit', 'Specific voltage requirements'],
    interviewQuestions: [
      { q: 'Why use ESP32 over ESP8266?', a: 'Dual cores, Bluetooth, and more peripherals.' }
    ]
  },

  {
    id: 'temp-sensor',
    name: 'Temperature Sensor',
    category: 'Sensor',
    description: 'Measures temperature changes and converts them into electrical signals. Used in weather stations, AC systems, and health devices.',
    symbol: 'TMP',
    image: '/src/assets/images/regenerated_image_1779185964744.webp',
    working: 'Varies electrical output proportional to thermal energy. Common types include Thermocouples and Thermistors.',
    applications: ['Weather stations', 'HVAC systems', 'Health monitoring', 'Coffee machines'],
    advantages: ['Precise', 'Fast feedback'],
    disadvantages: ['Requires calibration', 'Linearity issues'],
    interviewQuestions: [
      { q: 'What is a Thermocouple?', a: 'A sensor that produces a temperature-dependent voltage as a result of the Seebeck effect.' }
    ]
  },
  {
    id: 'ir-sensor',
    name: 'IR Sensor',
    category: 'Sensor',
    description: 'Detects infrared radiation or nearby objects without contact. Commonly used in obstacle detection and automatic doors.',
    symbol: 'IR',
    image: '/src/assets/images/regenerated_image_1779185961858.jpg',
    working: 'Emits IR radiation and detects the reflected light via a photodiode or phototransistor.',
    applications: ['Obstacle detection', 'Automatic doors', 'Line tracking', 'Proximity sensing'],
    advantages: ['Contactless', 'Low cost', 'Small footprint'],
    disadvantages: ['Affected by ambient light', 'Limited range'],
    interviewQuestions: [
      { q: 'How does IR proximity work?', a: 'By emitting an IR pulse and measuring the intensity of the reflection.' }
    ]
  },
  {
    id: 'ultrasonic-sensor',
    name: 'Ultrasonic Sensor',
    category: 'Sensor',
    description: 'Uses sound waves to measure distance between sensor and object. Used in parking systems and robotics.',
    symbol: 'ULTRA',
    image: '/src/assets/images/regenerated_image_1779185959350.webp',
    working: 'Emits a high-frequency sound wave and measures the time taken for the echo to return.',
    applications: ['Parking aid', 'Level sensing', 'Robot obstacle avoidance'],
    advantages: ['Unaffected by color/transparency', 'Great for distance measurement'],
    disadvantages: ['Blind spots', 'Sound absorption', 'Temp sensitive'],
    interviewQuestions: [
      { q: 'Formula for ultrasonic distance?', a: 'Distance = (Time × Speed of Sound) / 2.' }
    ]
  },
  {
    id: 'gas-sensor',
    name: 'Gas Sensor',
    category: 'Sensor',
    description: 'Detects harmful gases like LPG, smoke, CO, or methane. Used in gas leak alarms and safety systems.',
    symbol: 'GAS',
    image: '/src/assets/images/regenerated_image_1779185958497.webp',
    working: 'Involves a sensing material whose conductivity changes upon exposure to target gases.',
    applications: ['Gas leak alarms', 'Pollution monitors', 'Breathalyzers', 'Fire safety'],
    advantages: ['Life-saving', 'Automated alerts'],
    disadvantages: ['Requires pre-heating often', 'Cross-sensitivity to different gases'],
    interviewQuestions: [
      { q: 'How does an MQ series sensor work?', a: 'By heating a sensing element which changes resistance when gas molecules hit it.' }
    ]
  },
  {
    id: 'ldr-sensor',
    name: 'LDR Sensor',
    category: 'Sensor',
    description: 'Light Dependent Resistor changes resistance based on light intensity. Used in street lights and automatic lamps.',
    symbol: 'LDR',
    image: '/src/assets/images/regenerated_image_1779185956710.jpg',
    working: 'A variable resistor whose resistance decreases with increasing incident light intensity.',
    applications: ['Street lights', 'Solar trackers', 'Camera exposure control'],
    advantages: ['Simple', 'Inexpensive', 'Long life'],
    disadvantages: ['Slow response time', 'Inaccurate for precise lux measurement'],
    interviewQuestions: [
      { q: 'What happens to LDR resistance in dark?', a: 'It increases significantly (often to mega-ohms).' }
    ]
  },
  {
    id: 'vibration-sensor',
    name: 'Vibration Sensor',
    category: 'Sensor',
    description: 'Measures, displays, and analyzes linear velocity, displacement, and proximity or acceleration.',
    symbol: 'VIB',
    image: '/src/assets/images/regenerated_image_1779185955095.webp',
    working: 'Typically uses piezoelectric effects to convert mechanical motion into electrical signals.',
    applications: ['Condition monitoring', 'Seismic detection', 'Appliance testing'],
    advantages: ['Wide frequency range', 'Rugged', 'Sensitive'],
    disadvantages: ['Complex signal processing', 'Requires proper mounting'],
    interviewQuestions: [
      { q: 'What is a Piezoelectric sensor?', a: 'A device that uses the piezoelectric effect to measure changes in pressure, acceleration, temperature, strain, or force by converting them to an electrical charge.' }
    ]
  },
  {
    id: 'soil-moisture-sensor',
    name: 'Soil Moisture Sensor',
    category: 'Sensor',
    description: 'Measures the volumetric water content in soil by sensing its dielectric constant.',
    symbol: 'SOIL',
    image: '/src/assets/images/regenerated_image_1779185953949.jpg',
    working: 'Uses two probes to measure the resistance or capacitance of the soil, which changes with moisture.',
    applications: ['Smart agriculture', 'Automated gardening', 'Landscape irrigation'],
    advantages: ['Easy to integrate', 'Low cost'],
    disadvantages: ['Corrosion in soil', 'Inconsistent readings over time'],
    interviewQuestions: [
      { q: 'Why do probes corrode?', a: 'Electrolysis occurs when DC current is passed through the probes in moist soil.' }
    ]
  },
  {
    id: 'touch-sensor',
    name: 'Touch Sensor',
    category: 'Sensor',
    description: 'Detects physical touch or proximity of a finger. A durable and modern alternative to mechanical buttons.',
    symbol: 'TOUCH',
    image: '/src/assets/images/regenerated_image_1779185950764.png',
    working: 'Detects changes in capacitance when a conductive object (like a finger) comes close to the sensing area.',
    applications: ['Touchscreens', 'Smart lamps', 'Control panels'],
    advantages: ['Wear resistant', 'Modern aesthetic', 'Sealable against dust'],
    disadvantages: ['Sensitivity to moisture', 'False triggers possible'],
    interviewQuestions: [
      { q: 'Capacitive vs Resistive touch?', a: 'Capacitive sensors respond to electrical properties of skin; resistive respond to physical pressure.' }
    ]
  },
];

