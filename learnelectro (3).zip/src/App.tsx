import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Navbar from './components/layout/Navbar';
import Hero from './components/sections/Hero';
import Components from './components/sections/Components';
import VirtualLab from './components/sections/VirtualLab';
import EngineeringTools from './components/sections/EngineeringTools';
import Assessment from './components/sections/Assessment';
import Footer from './components/layout/Footer';
import AITutorFab from './components/ui/AITutorFab';

export default function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="relative min-h-screen flex flex-col">
      <div className="immersive-bg" />
      
      <Navbar 
        activeSection={activeSection} 
        setActiveSection={setActiveSection}
        onSearch={setSearchQuery} 
      />
      
      <main className="flex-1 pt-16 md:pt-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            {activeSection === 'home' && <Hero onExplore={setActiveSection} />}
            {activeSection === 'components' && <Components searchQuery={searchQuery} />}
            {activeSection === 'lab' && <VirtualLab />}
            {activeSection === 'tools' && <EngineeringTools searchQuery={searchQuery} />}
            {activeSection === 'quiz' && <Assessment />}
          </motion.div>
        </AnimatePresence>
      </main>

      <AITutorFab />
      <Footer />
    </div>
  );
}
