export interface CircuitPart {
  id: string;
  name: string;
  explanation: string;
  position: { x: number; y: number }; // Percentage based
}

export interface CircuitExample {
  id: string;
  title: string;
  diagram: string;
  description: string;
  parts: CircuitPart[];
  simulationResult?: string;
}

export interface ElectronicComponent {
  id: string;
  name: string;
  category: 'Passive' | 'Semiconductor' | 'IC' | 'Sensor';
  description: string;
  symbol: string;
  image: string;
  pinDiagram?: string;
  working: string;
  formula?: string;
  applications: string[];
  advantages: string[];
  disadvantages: string[];
  revisionNotes?: string[];
  interviewQuestions: { q: string; a: string }[];
  circuitExamples?: CircuitExample[];
}

export interface Project {
  id: string;
  title: string;
  description: string;
  image: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  components: string[];
  steps: string[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  category: string;
}
