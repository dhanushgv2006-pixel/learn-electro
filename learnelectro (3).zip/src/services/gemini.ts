import { GoogleGenAI } from "@google/genai";

const getAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is required");
  }
  return new GoogleGenAI({ apiKey });
};

export const generateEngineeringImage = async (prompt: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          text: `Engineering-style technical illustration: ${prompt}. Futuristic, clean, blueprint aesthetic, blueprint lines, electronic component detail, 4k, photorealistic lighting, dark blue and sky blue color palette.`,
        },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1",
      },
    },
  });

  const parts = response.candidates?.[0]?.content?.parts;
  if (!parts) return null;

  for (const part of parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
};

export const askAITutor = async (history: { role: 'user' | 'model'; parts: { text: string }[] }[], message: string) => {
  const ai = getAI();
  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: "You are LearnElectro's Advanced AI Tutor. You help engineering students understand electronic components, theory, and circuit design. You provide technical, accurate, and encouraging advice. Use Markdown for formatting.",
    },
    history,
  });

  const response = await chat.sendMessage({ message });
  return response.text;
};
